# geohash
R package for [geohashes](https://en.wikipedia.org/wiki/Geohash)

Encoding and decoding functions are derived from Leonard Norrgard's [Geohash Python lbrary](https://github.com/vinsci/geohash/).

License: GNU Affero General Public License
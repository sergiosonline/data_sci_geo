NEIGHBORHOODS_WGS84_readme
 

Column name  (Description)
======================================
AREA_S_CD = AREA_SHORT_CODE
AREA_NAME = AREA_NAME
